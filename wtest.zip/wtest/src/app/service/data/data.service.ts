import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators'

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
const Url = 'http://localhost:3000/v1';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }


  getFotos(): Observable<any> {
    return this.http.get(`${Url}/fotos`, httpOptions).pipe(
      map(this.extractData),
      catchError(this.handleError));
  }

  postFotos(data): Observable<any> {
    return this.http.post(`${Url}/fotos`, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
    
  deleteFotos(id: string): Observable<{}> {
       return this.http.delete( `${Url}/fotos/${id}`, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
    
      console.error('An error occurred:', error.error.message);
    } else {
    
      console.error(
        `Backend codigo retornado code ${error.status}, ` +
        `erro: ${error.error}`);
    }
  
    return throwError('Error na requisicao.');
  };  
  private extractData(res: Response) {
    let body = res;
    return body || { };
  }

}

import { Injectable } from '@angular/core';
import { NgFlashMessageService } from 'ng-flash-messages';
@Injectable({
  providedIn: 'root'
})
export class ShareService {
  
  constructor(private ngFlashMessageService: NgFlashMessageService) { }




  public MsgTootip(value) {

    this.ngFlashMessageService.showFlashMessage({
        // Array of messages each will be displayed in new line
        messages: [value], 
        // Whether the flash can be dismissed by the user defaults to false
        dismissible: true, 
        // Time after which the flash disappears defaults to 2000ms
        timeout: false,
        // Type of flash message, it defaults to info and success, warning, danger types can also be used
        type: 'success'
      });
    }

   

    public ErrorMsgTootip(value) {

        this.ngFlashMessageService.showFlashMessage({
            // Array of messages each will be displayed in new line
            messages: [value], 
            // Whether the flash can be dismissed by the user defaults to false
            dismissible: true, 
            // Time after which the flash disappears defaults to 2000ms
            timeout: false,
            // Type of flash message, it defaults to info and success, warning, danger types can also be used
            type: 'danger'
          });
        }
       
   
  }

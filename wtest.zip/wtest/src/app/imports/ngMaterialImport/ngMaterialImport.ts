import { NgModule } from '@angular/core';
import { LayoutModule } from '@angular/cdk/layout';
import {
  MatToolbarModule, MatButtonModule, MatInputModule, MatSidenavModule, MatIconModule, MatListModule,
  MatGridListModule, MatSnackBarModule, MatCardModule, MatMenuModule
} from '@angular/material';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatPaginatorModule } from '@angular/material';


@NgModule({
  imports: [MatToolbarModule, MatSnackBarModule, LayoutModule, MatInputModule, MatButtonModule, MatFormFieldModule, MatPaginatorModule,
    MatSidenavModule, MatIconModule, MatListModule, MatGridListModule, MatTableModule,
    MatCardModule, MatMenuModule],
  exports: [MatToolbarModule, MatSnackBarModule, MatButtonModule, MatInputModule, MatSidenavModule, LayoutModule, MatTableModule,
    MatIconModule, MatListModule, MatGridListModule, MatFormFieldModule, MatPaginatorModule,
    MatCardModule, MatMenuModule]
})
export class CustomMaterialModule { }
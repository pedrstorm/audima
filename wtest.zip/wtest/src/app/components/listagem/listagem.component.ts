import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';

import { APIData } from '../../models/interface/Iapi';
import { DataService } from '../../service/data/data.service';
import { ShareService } from '../../service/share.service';

@Component({
  selector: 'app-listagem',
  templateUrl: './listagem.component.html',
  styleUrls: ['./listagem.component.css']
})
export class ListagemComponent implements OnInit {
  displayedColumns: string[] = [ 'titulo', 'url', 'op'];
  dataSource: MatTableDataSource<APIData> = new MatTableDataSource();
 users : any = [{_id:0 ,titulo :'...' ,url:'...'}];

  constructor(private FotoService: DataService,private share:ShareService) {


  }

  ngOnInit()  {
    

this.FotoService.getFotos().subscribe(res => {

  this.dataSource.data = res;


}, err => {

  this.dataSource.data = this.users;

});



  }


eliminar (id){
 
  this.FotoService.deleteFotos(id).subscribe(res => {
    this.FotoService.getFotos().subscribe(res => {
      this.share.MsgTootip('Eliminado com sucesso');
      this.dataSource.data = res;} );    }, err => {
        this.share.ErrorMsgTootip('Erro ao eliminar o arquivo');
     
    });
  
  }
    







  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}


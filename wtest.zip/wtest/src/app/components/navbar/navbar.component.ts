import { Component ,OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../../guard/auth/auth.service';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  usuario ;
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
    isLoggedIn$: Observable<boolean>;
  constructor(private breakpointObserver: BreakpointObserver,private authService: AuthService) {}






  ngOnInit() {
    this.isLoggedIn$ = this.authService.isLoggedIn;
   this.usuario = JSON.parse(localStorage.getItem('Login'));
  }

  onLogout() {
    this.authService.logout();
  }
  
  }

import {Component, ElementRef, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { DataService } from '../../service/data/data.service';
import { ShareService } from '../../service/share.service';


@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent  {
  dados: FormGroup;
  @ViewChild('fileInput') fileInput: ElementRef;
  
  constructor(private _formBuilder: FormBuilder ,private share:ShareService, private FotoService: DataService ) { 

    this.dados = this._formBuilder.group({
    
      titulo: ['', Validators.required],
       url :null

    });
  }


  save (){

    const form = {titulo : this.dados.get('titulo').value , url : this.transarr(this.dados.get('url').value)};
   this.FotoService.postFotos(form).subscribe(res => {

    this.share.MsgTootip('Cadastrado com sucesso');
  
  }, err => {
  
    this.share.ErrorMsgTootip('Erro : Tamanho do arquivo , tente outra imagem');
  
  
  });
  

   
  }


  onFileChange(event) {
    const  reader = new FileReader();
    if(event.target.files && event.target.files.length > 0) {
      const  file = event.target.files[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.dados.get('url').setValue({
          filename: file.name,
          filetype: file.type,
          value: reader.result.split(',')[1]
        })
      };
    }
  }

  transarr(url ){
    return `data:image/jpeg;base64,${url.value}`;

  }

}

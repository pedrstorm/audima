import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AuthService } from '../../guard/auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
mostrar ;

dados1: FormGroup;
  constructor(private _formBuilder: FormBuilder , private authService: AuthService) {

    this.dados1 = this._formBuilder.group({
      nome: ['', Validators.required],
      senha: ['', Validators.required],
    });
  }

  ngOnInit() {
  }


  login() {

    if (this.dados1.valid) {
      this.authService.login(this.dados1.value);
    }
 



  }

}

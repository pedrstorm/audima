export interface APIData {
  _id: string;
    titulo: string;
    url: string|any;
  }
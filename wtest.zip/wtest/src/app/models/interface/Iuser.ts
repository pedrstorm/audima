export interface Iuser {
    nome: string;
    senha: string;
};
  